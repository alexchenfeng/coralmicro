elftosb 5.1.19

Command-line tool for converting an ELF/SREC formatted application image to SB format.

Platform supported
=====================
LPC55Sxx, LPC55xx, RT5xx, RT6xx, LPC54S0xx, RT10xx

System requirements
=====================
Linux: GLIBC v2.25， libraries like libstdc++6, libudev-dev, libc6 and libgcc1 may also need to be installed
Apple Mac: MacOS High Sierra v10.13.3

Release contents
=====================
elftosb executables: bin/
elftosb user's guide: docs/
elftosb build projects and source code: proj/

Development tools
=====================
Windows: Microsoft Visual Studio Professional 2015 for Windows OS Desktop
Linux: GNU C Compiler (GCC) v7.4.0, GLIBC v2.25, libraries like libstdc++6, libudev-dev, libc6 and libgcc1 may also need to be installed
Apple Mac: MacOS High Sierra v10.13.3, Apple Xcode v9.2 (for tools)
